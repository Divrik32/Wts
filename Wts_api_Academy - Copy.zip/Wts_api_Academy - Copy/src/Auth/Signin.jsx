import React from "react";
import { Form, Button } from "react-bootstrap";
import "./signin.css";
import { useForm } from "react-hook-form";
import BackgroundImage from "../assets/images/background.png";
import Logo from "../assets/images/logo.png";
import { useNavigate } from "react-router-dom";
import ApiHandler from "../Api/ApiHandler";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useDispatch } from "react-redux";
import { login } from "../redux/slice/authSlice";
import { toast } from "react-toastify";
import {
  MDBBtn,
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBIcon,
  MDBInput,
} from "mdb-react-ui-kit";

const Signin = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const queryClient = useQueryClient();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  //handle signIn method
  const { mutate } = useMutation({
    mutationFn: ApiHandler.userSignIn,
    onSuccess: (response) => {
      if (response?.status == 200) {
        const token = response?.token;
        const name = response?.data?.first_name;
        const profileImage = response?.data?.profile_pic;

        localStorage.setItem("token", token);
        localStorage.setItem("Name", name);
        localStorage.setItem("proimg", profileImage);

        dispatch(login({ token, user: name, profileImage }));
        toast.success(response?.message, {
          onClose: () => navigate("/"),
        });
      } else {
        toast.error(response?.message);
      }
      queryClient.invalidateQueries({ queryKey: ["users"] });
    },
  });

  const onSubmit = (data) => mutate(data);

  return (
    <>
      {/* <div
        className="sign-in__wrapper"
        style={{ backgroundImage: `url(${BackgroundImage})` }}
      >
        <div className="sign-in__backdrop"></div>
        <Form
          className="shadow p-4 bg-white rounded"
          onSubmit={handleSubmit(onSubmit)}
        >
          <img
            className="img-thumbnail mx-auto d-block mb-2"
            src={Logo}
            alt="logo"
          />
          <div className="h4 mb-2 text-center">Sign In</div>
          <Form.Group className="mb-2" controlId="email">
            <Form.Label>Email</Form.Label>
            <Form.Control
              type="email"
              placeholder="Email"
              required
              {...register("email", { required: true })}
            />
            {errors.email && <span>This field is required</span>}
          </Form.Group>
          <Form.Group className="mb-2" controlId="password">
            <Form.Label>Password</Form.Label>
            <Form.Control
              type="password"
              placeholder="Password"
              required
              {...register("password", { required: true })}
            />
            {errors.password && <span>This field is required</span>}
          </Form.Group>
          <Form.Group className="mb-2" controlId="checkbox">
            <Form.Check type="checkbox" label="Remember me" />
          </Form.Group>
          <Button className="w-100" variant="primary" type="submit">
            Log In
          </Button>
          <div className="d-grid justify-content-end">
            <Button
              className="text-muted px-0"
              variant="link"
              onClick={() => navigate("/signup")}
            >
              Create an Account
            </Button>
          </div>
        </Form>
        <div className="w-100 mb-2 position-absolute bottom-0 start-50 translate-middle-x text-white text-center">
          Made by Webskitters Academy| &copy;2024
        </div>
      </div> */}
      <MDBContainer fluid>
        <MDBRow>
          <MDBCol sm="6">
            <div className="d-flex flex-row ps-5 pt-5">
              <MDBIcon
                fas
                icon="crow fa-3x me-3"
                style={{ color: "#709085" }}
              />
              <span className="h1 fw-bold mb-0">Please Sign In the form!</span>
            </div>
            <Form
              className="shadow p-4 bg-white rounded"
              onSubmit={handleSubmit(onSubmit)}
              >
              <div className="d-flex flex-column justify-content-center h-custom-2 w-75 pt-4">
                <h3
                  className="fw-normal mb-3 ps-5 pb-3"
                  style={{ letterSpacing: "1px" }}
                >
                  Log in
                </h3>
                <MDBInput
                  wrapperClass="mb-4"
                  label="Email address"
                  id="formControlLg"
                  type="email"
                  size="lg"
                  {...register("email", {
                    required: true,
                  })}
                />
                <MDBInput
                  wrapperClass="mb-4"
                  label="Password"
                  id="formControlLg"
                  type="password"
                  size="lg"
                  {...register("password", {
                    required: true,
                  })}
                />
                <Form.Group className="mb-2" controlId="checkbox">
                  <Form.Check type="checkbox" label="Remember me" />
                </Form.Group>
                <MDBBtn className="mb-4  w-100"  color="info" size="lg">
                  Login
                </MDBBtn>

               <p className="text-muted" style={{marginLeft:'177px',marginBottom:'-1px'}}> Don't have an Account? 
               </p>
               <Button
                  className=" px-0"
                  variant="link"
                  onClick={() => navigate("/signup")}
                  style={{color:"#000070",background:'#ff0000'}}
                >
                  Create an Account
                </Button>

              </div>
            </Form>
          </MDBCol>

          <MDBCol sm="6" className="d-none d-sm-block px-0">
            <img
              src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/img3.webp"
              alt="Login image"
              className="w-100"
              style={{
                objectFit: "cover",
                objectPosition: "left",
                height: "600px",
                marginTop: "3px"
              }}
            />
          </MDBCol>
        </MDBRow>
        <div
          style={{ height: "100px", paddingTop: "20px",marginTop: "3px",width:'2030px' }}
          className=" mb-2 position-relative bottom-0 start-50 translate-middle-x bg-dark text-white text-center"
        >
          Made by Webskitters Academy| &copy;2024
        </div>
      </MDBContainer>
    </>
  );
};

export default Signin;
