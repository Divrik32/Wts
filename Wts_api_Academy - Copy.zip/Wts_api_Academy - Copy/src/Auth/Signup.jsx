import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { Form, Button } from "react-bootstrap";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import ApiHandler from "../Api/ApiHandler";
import { ToastContainer, toast } from "react-toastify";
import "./signup.css";
import BackgroundImage from "../assets/images/register.jpg";
import { useNavigate } from "react-router-dom";
import {
  MDBBtn,
  MDBContainer,
  MDBCard,
  MDBCardBody,
  MDBCardImage,
  MDBRow,
  MDBCol,
  MDBInput,
  MDBFile
} from "mdb-react-ui-kit";

const Signup = () => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  //mutation nethod for signUp

  const { mutate } = useMutation({
    mutationFn: ApiHandler?.userSignUp,
    onSuccess: (response) => {
      if (response?.status === 200) {
        toast.success(response?.message, {
          onClose: () => navigate("/signin"),
        });
      } else {
        toast.error(response?.message);
      }
      queryClient.invalidateQueries({ queryKey: ["users"] });
    },
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  //image handle

  const [img, setImg] = useState(null);

  //form submit

  const onSubmit = (data) => {
    const formData = new FormData();
    formData.append("first_name", data.first_name);
    formData.append("last_name", data.last_name);
    formData.append("email", data.email);
    formData.append("password", data.password);
    if (img) {
      formData.append("profile_pic", img);
    }
    mutate(formData);
  };

  return (
    <>
      {/* <div
        className="sign-in__wrapper text-center"
        style={{ backgroundImage: `url(${BackgroundImage})` }}
      >
        <h2 className="text-center text-info">Signup Page</h2>
        <form
          className="shadow p-4 bg-white rounded"
          onSubmit={handleSubmit(onSubmit)}
        >
          <div className="mb-3">
            <label htmlFor="exampleInputFirstName" className="form-label">
              First Name
            </label>
            <input
              type="text"
              name="first_name"
              className="form-control"
              id="exampleInputFirstName"
              {...register("first_name", { required: true })}
            />
            {errors.first_name && <span>This field is required</span>}
          </div>
          <div className="mb-3">
            <label htmlFor="exampleInputLastName" className="form-label">
              Last Name
            </label>
            <input
              type="text"
              name="last_name"
              className="form-control"
              id="exampleInputLastName"
              {...register("last_name", { required: true })}
            />
            {errors.last_name && <span>This field is required</span>}
          </div>
          <div className="mb-3">
            <label htmlFor="exampleInputemail1" className="form-label">
              email address
            </label>
            <input
              type="email"
              name="email"
              className="form-control"
              id="exampleInputemail1"
              {...register("email", { required: true })}
            />
            {errors.email && <span>This field is required</span>}
          </div>
          <div className="mb-3">
            <label htmlFor="exampleInputPassword1" className="form-label">
              Password
            </label>
            <input
              type="password"
              name="password"
              className="form-control"
              id="exampleInputPassword1"
              {...register("password", { required: true })}
            />
            {errors.password && <span>This field is required</span>}
          </div>
          <div className="mb-3">
            <label htmlFor="exampleInputProfilePic" className="form-label">
              Profile Picture
            </label>
            <input
              type="file"
              onChange={(e) => setImg(e.target.files[0])}
              accept="image/*"
              className="form-control"
            />
            {img && (
              <img
                style={{ height: "180px" }}
                src={URL.createObjectURL(img)}
                alt=""
                className="upload-img"
              />
            )}
          </div>
          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </form>
      </div> */}
      <MDBContainer fluid>
        <MDBRow
          className="d-flex justify-content-center align-items-center"
          style={{ background: "#00FFC0" }}
        >
          <MDBCol lg="8">
            <MDBCard className=" my-5  rounded-3" style={{ maxWidth: "600px",marginLeft:'250px' }}>
              <MDBCardImage
                src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/img3.webp"
                className="w-100 rounded-top"
                alt="Sample photo"
              />

              <MDBCardBody className="px-5">
                <h3 className="mb-4 pb-2 pb-md-0 mb-md-5 px-md-2">
                  Registration Info
                </h3>
                <Form
          onSubmit={handleSubmit(onSubmit)}
        >
                <MDBRow>
                  <MDBCol md="6">
                    <MDBInput
                      wrapperClass="mb-4"
                      label="first_name"
                      id="formControlLg"
                      type="text"
                      size="lg"
                      {...register("first_name", {
                        required: true,
                      })}
                    />
                  </MDBCol>
                </MDBRow>

                <MDBRow>
                  <MDBCol md="6">
                    <MDBInput
                      wrapperClass="mb-4"
                      label="last_name"
                      id="formControlLg"
                      type="text"
                      size="lg"
                      {...register("last_name", {
                        required: true,
                      })}
                    />
                  </MDBCol>
                </MDBRow>
                <MDBRow>
                  <MDBCol md="6">
                    <MDBInput
                      wrapperClass="mb-4"
                      label="Email address"
                      id="formControlLg"
                      type="email"
                      size="lg"
                      {...register("email", {
                        required: true,
                      })}
                    />
                  </MDBCol>
                </MDBRow>
                <MDBRow>
                  <MDBCol md="6">
                    <MDBInput
                      wrapperClass="mb-4"
                      label="Password"
                      id="formControlLg"
                      type="password"
                      size="lg"
                      {...register("password", {
                        required: true,
                      })}
                    />
                  </MDBCol>
                </MDBRow>
                <MDBRow>
                  <MDBCol md="6">
                    <MDBFile
                      size="lg"
                      id="customFile"
                      type="file"
                      onChange={(e) => setImg(e.target.files[0])}
                    />
                  </MDBCol>
                </MDBRow>
                {img && (
                  <img
                    style={{ height: "180px" }}
                    src={URL.createObjectURL(img)}
                    alt=""
                    className="upload-img"
                  />
                )}<br />
                <MDBBtn color="success" className="mb-4" size="lg">
                  Submit
                </MDBBtn>

                <p className="text-muted"  style={{marginBottom:'0px'}}> Already have an Account? 
               </p>
               <Button
                  className=" px-0"
                  variant="link"
                  onClick={() => navigate("/signin")}
                  style={{color:"#000070",background:'#ff0000',width:'250px'}}
                >
                  Log In Here
                </Button>


                </Form>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>
        <div
          style={{ height: "100px", paddingTop: "20px",width:'2030px' }}
          className=" mb-2 position-relative bottom-0 start-50 translate-middle-x bg-dark text-white text-center"
        >
          Made by Webskitters Academy| &copy;2024
        </div>
      </MDBContainer>
      <ToastContainer />
    </>
  );
};

export default Signup;
